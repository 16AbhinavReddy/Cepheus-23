#include <iostream>
#include <bits/stdc++.h>

using namespace std;

    int countPoints(string rings) {
        int R[10]={0};
        int G[10]={0};
        int B[10]={0};
        
        for(int i=0;i<rings.length();i+=2)
        {
            int rod= rings[i+1]-'0';
            if(rings[i]=='R'){
                R[rod]++;
            }
            else if(rings[i]=='G'){
                G[rod]++;
            }
            else{
                B[rod]++;
            }
        }
        int count=0;
        for(int i=0;i<10;i++)
        {
            if(R[i]>0 && G[i]>0 && B[i]>0)
                count++;
        }
        return count;
    }







int main() {

    for(int i = 1; i <= 5; ++i){
        string pathone = "outputs\\output0" + to_string(i) + ".txt";
        freopen(pathone.c_str(), "w", stdout);

        string pathon = "inputs\\input0" + to_string(i) + ".txt";
        freopen(pathon.c_str(), "r", stdin);
    
    int t;
    cin>>t;
    
    while(t--){
        // int a,b,c;
        string a;
        cin>>a;
        int finres =countPoints(a);
        
        cout<<finres<<endl;
    }
    }
}