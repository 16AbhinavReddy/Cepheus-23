#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main() {

    for(int i = 1; i <= 5; ++i){
        string pathone = "outputs\\output0" + to_string(i) + ".txt";
        freopen(pathone.c_str(), "w", stdout);

        string pathon = "inputs\\input0" + to_string(i) + ".txt";
        freopen(pathon.c_str(), "r", stdin);
    
    long t;
    cin>>t;
    while(t--){
        long n, k; scanf("%ld %ld", &n, &k);
        std::vector<std::pair<long, long> > v(n);
        for(long p = 0; p < n; p++){scanf("%ld", &v[p].first);}
        for(long p = 0; p < n; p++){scanf("%ld", &v[p].second);}
        sort(v.begin(), v.end());
        long ram(k);
        for(long p = 0; p < n; p++){
            if(ram < v[p].first){break;}
            ram += v[p].second;
        }

        // printf("%ld\n", ram);
        cout<<ram<<endl;
    }
}
}