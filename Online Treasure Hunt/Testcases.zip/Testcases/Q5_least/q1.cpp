// #include <iostream>
#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
#define sf scanf
#define pf printf
typedef long long ll;
#include <bits/stdc++.h>
using namespace std;

int gcd(int a, int b)
{
    if(b==0)
    {
        return a;
    }
    return gcd(b, a%b);
}


int main() {

    for(int i = 1; i <= 5; ++i){
        string pathone = "outputs\\output0" + to_string(i) + ".txt";
        freopen(pathone.c_str(), "w", stdout);

        string pathon = "inputs\\input0" + to_string(i) + ".txt";
        freopen(pathon.c_str(), "r", stdin);
    
    int t;
    cin>>t;
    
    while(t--){
        int a, b, n;
        sf("%d%d%d", &a, &b, &n);
        while(1)
        {
            n= n-gcd(a, n);
            if(n<=0)
            {
                pf("0\n");
                break;
            }
            n= n-gcd(b, n);
            if(n<=0)
            {
                pf("1\n");
                break;
            }
        }
    }
    }
}