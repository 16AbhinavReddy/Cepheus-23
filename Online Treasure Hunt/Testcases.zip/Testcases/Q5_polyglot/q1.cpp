#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int main() {

    for(int i = 1; i <= 5; ++i){
        string pathone = "outputs\\output0" + to_string(i) + ".txt";
        freopen(pathone.c_str(), "w", stdout);

        string pathon = "inputs\\input0" + to_string(i) + ".txt";
        freopen(pathon.c_str(), "r", stdin);
    
    int t;
    cin>>t;
    
    while(t--){
        int n;
        cin >> n;
        vector<int> a(n);
        for (int j = 0; j < n; j++) {
            cin >> a[j];
        }
        sort(a.begin(), a.end());
        cout << a[n - 1] - a[0] + 1 - n << endl;
        // return 0;
    }
    }
}