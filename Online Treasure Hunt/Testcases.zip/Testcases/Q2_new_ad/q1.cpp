#include <iostream>
#include <bits/stdc++.h>


using namespace std;


vector<vector<int>> sortTheStudents(vector<vector<int>>& score, int k) {
        for(auto &r : score) r.insert(r.begin(), r[k]);
        sort(score.begin(), score.end(), greater<vector<int>>());
        for(auto &r : score) r.erase(r.begin());
        return score;
}

int main() {

    for(int i = 1; i <= 5; ++i){
        string pathone = "outputs\\output0" + to_string(i) + ".txt";
        freopen(pathone.c_str(), "w", stdout);

        string pathon = "inputs\\input0" + to_string(i) + ".txt";
        freopen(pathon.c_str(), "r", stdin);
    
    int t;
    cin>>t;
    
    while(t--){
        int k;
        cin>>k;
        int r,c;
        cin>>r>>c;
        vector<vector<int>> nums2;
        for (int h=0;h<r;h++){
            vector<int> nums1;
            for (int g=0;g<c;g++){
                int val;
                cin>>val;
                nums1.push_back(val);

            }
            nums2.push_back(nums1);
            
        }
        vector<vector<int>> fin = sortTheStudents(nums2,k);

        // cin>>a>>b>>c;
        for (int po=0;po<r;po++){
            for (int po1=0;po1<c;po1++){
                cout<<fin[po][po1]<<" ";
            }
            cout<<endl;
        }
        // cout<<max(a, max(b,c))<<endl;
    }
    }
}