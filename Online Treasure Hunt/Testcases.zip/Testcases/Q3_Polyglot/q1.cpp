#include <iostream>

using namespace std;

int main() {

    for(int i = 1; i <= 5; ++i){
        string pathone = "outputs\\output0" + to_string(i) + ".txt";
        freopen(pathone.c_str(), "w", stdout);

        string pathon = "inputs\\input0" + to_string(i) + ".txt";
        freopen(pathon.c_str(), "r", stdin);
    
    int t;
    cin>>t;
    
    while(t--){
        int z;
        cin>>z;
        int s=1,n=z,sums=1,sumb=n;
        if(n==s){cout<<n<<endl;}
        while(s<n){
            if(sums<sumb)
                sums+=++s;
            else
                sumb+=--n;
            if(sums==sumb && n!=z && s+1==n-1){cout<<s+1<<endl;};
        }
    
        cout<<-1<<endl;
    }
    }
}