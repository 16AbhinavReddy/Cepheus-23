#include <iostream>
#include <bits/stdc++.h>


using namespace std;

int reductionOperations(vector<int>& nums) {
        sort(nums.begin(),nums.end(),greater<int>());
        int ans=0;
        int idx=0;
        int c=0;
        int n=nums[nums.size()-1];
        while(idx<nums.size() and nums[idx]!=n)
        {
            int ele=nums[idx];
            //c=0;
            while(idx<nums.size() and ele==nums[idx])
            {
                c++;
                idx++;
            }
            if(idx<nums.size() and ele!=nums[idx])
            ans=ans+c;
        }
        return ans;
    }

int main() {

    for(int i = 1; i <= 5; ++i){
        string pathone = "outputs\\output0" + to_string(i) + ".txt";
        freopen(pathone.c_str(), "w", stdout);

        string pathon = "inputs\\input0" + to_string(i) + ".txt";
        freopen(pathon.c_str(), "r", stdin);
    
    int t;
    cin>>t;
    
    while(t--){
        int a;
        cin>>a;
        vector<int> nums;
        for (int g=0;g<a;g++){
            int b;
            cin>>b;
            nums.push_back(b);

        }
        // cin>>a>>b>>c;
        int finres = reductionOperations(nums);
        
        cout<<finres<<endl;
    }
    }
}