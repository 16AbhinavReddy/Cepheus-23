#include <iostream>
#include <bits/stdc++.h>


using namespace std;

int garbageCollection(vector<string>& garbage, vector<int>& travel) {
        bool fg=false,fp=false,fm=false;
        int g=0,p=0,m=0;
        for(int i=garbage.size()-1;i>=0;i--)
        {
            for(char c:garbage[i])
            {
                if(c=='G'){g++; fg=true;}
                else if(c=='P'){ p++;fp=true;}
                else if(c=='M') {m++; fm=true;}
            }
            if (i!=0 && fg==true)g+=travel[i-1];
            if (i!=0 && fp==true)p+=travel[i-1];
            if (i!=0 && fm==true)m+=travel[i-1];
        }
        return g+m+p;
    }



int main() {

    for(int i = 1; i <= 5; ++i){
        string pathone = "outputs\\output0" + to_string(i) + ".txt";
        freopen(pathone.c_str(), "w", stdout);

        string pathon = "inputs\\input0" + to_string(i) + ".txt";
        freopen(pathon.c_str(), "r", stdin);
    
    int t;
    cin>>t;
    
    while(t--){
        int a;
        cin>>a;
        vector<string> wost;
        vector<int> wost1;
        for (int h=0;h<a;h++){
            string wo;
            cin>>wo;
            wost.push_back(wo);
        }
        for (int g=0;g<a-1;g++){
            int wonum;
            cin>>wonum;
            wost1.push_back(wonum);
        }
        // cin>>a>>b>>c;
        int finres = garbageCollection(wost,wost1);
        
        cout<<finres<<endl;
    }
    }
}