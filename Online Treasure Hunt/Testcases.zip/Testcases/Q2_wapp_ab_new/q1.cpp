#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int maxChunksToSorted(vector<int>& arr) {        
        int n=arr.size();
        int part=0,togo=INT_MIN;   
        for(int i=0;i<n;i++){
            if(i>togo && arr[i]>togo){
                part++;
            }
            togo=max(togo,arr[i]);                      
        }
        return part;
    }

int main() {

    for(int i = 1; i <= 5; ++i){
        string pathone = "outputs\\output0" + to_string(i) + ".txt";
        freopen(pathone.c_str(), "w", stdout);

        string pathon = "inputs\\input0" + to_string(i) + ".txt";
        freopen(pathon.c_str(), "r", stdin);
    
    int t;
    cin>>t;
    
    while(t--){
        int a;
        cin>>a;
        vector<int> nums;
        for (int h=0;h<a;h++){
            int b;
            cin>>b;
            nums.push_back(b);
        }
        int finres = maxChunksToSorted(nums);

        // cin>>a>>b>>c;
        
        cout<<finres<<endl;
    }
    }
}