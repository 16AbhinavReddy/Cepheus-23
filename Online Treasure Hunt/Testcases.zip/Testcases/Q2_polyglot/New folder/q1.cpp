#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main() {

    for(int i = 1; i <= 5; ++i){
        string pathone = "outputs\\output0" + to_string(i) + ".txt";
        freopen(pathone.c_str(), "w", stdout);

        string pathon = "inputs\\input0" + to_string(i) + ".txt";
        freopen(pathon.c_str(), "r", stdin);
    
    int t;
    cin>>t;
    vector<int> nums;

    while (t--){
        int c;

        cin>>c;
        nums.push_back(c);
    }

    int res=0;
        for(int i=0;i<nums.size();i++){
            res^=nums[i];
        }
        cout<<res<<endl;
    }

}