#include <iostream>
#include <bits/stdc++.h>

using namespace std;
vector<int> rearrangeArray(vector<int>& nums) {
        int n = nums.size();
         vector<int> ans(n,0);
        int indexpos = 0, indexneg=1;
        for(auto num: nums){
            if(num>0){
                ans[indexpos] = num;
                indexpos+=2;
            }
            if(num<0){
                ans[indexneg] = num;
                indexneg += 2;
            }
        }
        return ans;
        
    }





int main() {

    for(int i = 1; i <= 5; ++i){
        string pathone = "outputs\\output0" + to_string(i) + ".txt";
        freopen(pathone.c_str(), "w", stdout);

        string pathon = "inputs\\input0" + to_string(i) + ".txt";
        freopen(pathon.c_str(), "r", stdin);
    
    int t;
    cin>>t;
    
    while(t--){
        int a;
        cin>>a;
        vector<int> nums;
        for (int h=0;h<a;h++){
            int b;
            cin>>b;
            nums.push_back(b);

            

        }
        vector<int> finout = rearrangeArray(nums);
        for (int u=0;u<a;u++){
            cout<<finout[u]<<" ";
        }
        cout<<endl;
        // cin>>a>>b>>c;
        
        // cout<<max(a, max(b,c))<<endl;
    }
    }
}